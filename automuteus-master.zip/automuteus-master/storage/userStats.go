package storage

type UserStats struct {
	UserID      string `json:"userID"`
	GamesPlayed int    `json:"gamesPlayed"`
}
